import 'package:flutter/services.dart';

class BybAccessory {
  static const MethodChannel _channel = MethodChannel('byb_accessory');

  Future<String?> getPlatformVersion() async {
    return _channel.invokeMethod<String>('getPlatformVersion');
  }

  static Future<void> initWithProtocol(String protocol) async {
    await _channel.invokeMethod('initWithProtocol', {'protocol': protocol});
  }

  static Future<void> setProtocol(String protocol) async {
    await _channel.invokeMethod('setProtocol', {'protocol': protocol});
  }

  static Future<List<String>> getConnectedAccessories() async {
    final List<dynamic> accessories = await _channel.invokeMethod('getConnectedAccessories');
    return accessories.cast<String>();
  }

  static Future<bool> connect({String? name}) async {
    final bool? connected = await _channel.invokeMethod(
      'connect',
      name == null ? <String, dynamic>{} : {'name': name},
    );
    return connected ?? false;
  }

  static Future<void> disconnect() async {
    await _channel.invokeMethod('disconnect');
  }

  static Future<bool> isConnected() async {
    final bool? connected = await _channel.invokeMethod('isConnected');
    return connected ?? false;
  }

  static Future<String> getAccessoryInfo() async {
    final String? info = await _channel.invokeMethod('getAccessoryInfo');
    return info ?? 'Accessory Not Connected';
  }
}